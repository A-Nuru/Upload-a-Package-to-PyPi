from setuptools import setup

setup(name='eko_probability01',
      version='0.5',
      description='Gaussian and Binomial distributions',
      packages=['eko_probability01'],
      author = 'Nurudeen Adesina',
      author_email = 'access2abey@gmail.com',
      zip_safe=False)
